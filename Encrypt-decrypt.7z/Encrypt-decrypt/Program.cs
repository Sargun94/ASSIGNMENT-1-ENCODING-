﻿using System;
using System.Linq;

namespace Encrypt_decrypt
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                Console.WriteLine("Enter Your Full Name for Binary conversion:");
                String name = Console.ReadLine();
                Console.WriteLine("\nBinary value of Name:\n" + Encrypter.StringToBinary1(name));

                Console.WriteLine("\nEnter a Binary value:");
                String name1 = Console.ReadLine();
                Console.WriteLine("\nString For Binary Value:\n" + Encrypter.ConvertBinaryToString(name1));

                Console.WriteLine("\nEnter Your Name for Hexadecimal Value:");
                String name2 = Console.ReadLine();
                Console.WriteLine("\nHexadecimal value of Name:\n" + Encrypter.StringToHex2(name2));

                Console.WriteLine("\nEnter Hexadecimal Value:");
                String name3 = Console.ReadLine();
                Console.WriteLine("\nString For Hexadecimal Value:\n" + Encrypter.HexStringToString(name3));

                Console.WriteLine("\nEnter Your Name for Base64:");
                String name4 = Console.ReadLine();
                Console.WriteLine("\nBase64 value for Name:\n" + Encrypter.StringToBase64(name4));

                Console.WriteLine("\nEnter BASE64 Value:");
                String name5 = Console.ReadLine();
                Console.WriteLine("\nString For Base64 Value:\n" + Encrypter.Base64ToString(name5));

                Console.WriteLine("\nEnter your name for Cipher Text:");
                String unicodeString = Console.ReadLine();



                int[] cipher = new[] { 1, 1, 2, 3, 5, 8, 13 }; //Fibonacci Sequence
                string cipherasString = String.Join(",", cipher.Select(x => x.ToString())); //FOr display

                int encryptionDepth = 20;

                Encrypter encrypter = new Encrypter(unicodeString, cipher, encryptionDepth);

                //Single Level Encrytion
                string nameEncryptWithCipher = Encrypter.EncryptWithCipher(unicodeString, cipher);
                Console.WriteLine($"Encrypted once using the cipher {{{cipherasString}}} {nameEncryptWithCipher}");

                string nameDecryptWithCipher = Encrypter.DecryptWithCipher(nameEncryptWithCipher, cipher);
                Console.WriteLine($"Decrypted once using the cipher {{{cipherasString}}} {nameDecryptWithCipher}");

                //Deep Encrytion
                string nameDeepEncryptWithCipher = Encrypter.DeepEncryptWithCipher(unicodeString, cipher, encryptionDepth);
                Console.WriteLine($"Deep Encrypted {encryptionDepth} times using the cipher {{{cipherasString}}} {nameDeepEncryptWithCipher}");

                string nameDeepDecryptWithCipher = Encrypter.DeepDecryptWithCipher(nameDeepEncryptWithCipher, cipher, encryptionDepth);
                Console.WriteLine($"Deep Decrypted {encryptionDepth} times using the cipher {{{cipherasString}}} {nameDeepDecryptWithCipher}");

                //Base64 Encoded
                Console.WriteLine($"Base64 encoded {unicodeString} {encrypter.Base64}");

                string base64toPlainText = Encrypter.Base64ToString(encrypter.Base64);
                Console.WriteLine($"Base64 decoded {encrypter.Base64} {base64toPlainText}");

                Console.WriteLine("\n\n\nDo you want to exit(Enter 1) or continue(Enter any Number other than 1 to Continue) ");
                int exit_cont = Convert.ToInt32(Console.ReadLine());
                if(exit_cont == 1)
                {
                    break;
                }
            } while (true);
        }
    }
}
